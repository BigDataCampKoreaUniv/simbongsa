#import SQLAlchemy as SQLAlchemy
from flask import Flask, render_template,request
#from flask_sqlalchemy import SQLAlchemy
from flask_admin import Admin

from flask import Flask
import sqlite3


app = Flask(__name__)
#app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///testuser.db'
#app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True

#db = SQLAlchemy(app)
admin = Admin(app)


"""
class Content(db.Model):
    __tablename__ = 'content'

    id = db.Column(db.String, primary_key=True)
    title = db.Column(db.VARCHAR, nullable=False)
    recruit_office = db.Column(db.VARCHAR)
    recruit_startdate = db.Column(db.VARCHAR)
    recruit_enddate = db.Column(db.VARCHAR)
    activity_startdate = db.Column(db.VARCHAR)
    activity_enddate = db.Column(db.VARCHAR)
    contents = db.Column(db.Text)
    category = list(db.Column(db.Integer) for i in range(22))
    likecount = db.Column(db.Integer, default=0)
    receiver_disabled = db.Column(db.Integer)

place
contents   recruit_startdate   recruit_enddate   activity_date   category_life   category_world   category_environment   category_human   category_disaster   category_country   category_home   category_medic   category_education   category_administration   category_consulting   category_culture   category_physical   category_history   category_circles   category_travel   category_marketign   category_social   category_plan   category_language   category_scene   category_etc   recruit_disabled   recurit_oldman   recruit_foreigner   recruit_homeless   recruit_multiculture   recruit_worker   recruit_baby   recruit_women   recruit_zzokbang   recruit_teenager   recruit_nation   city1   city2   address   latitude   longitude
"""

#    pwd = db.Column(db.String, nullable=False)
def classification(categories):
    category_num = 22
    receiver_cate_num = 11
#    category_names = []
#    category_receivers = []
    category_names = ''
    category_receivers = ''

    category_dict = {0:'생활편의', 1:'국제협력', 2:'환경', 3:'인권', 4:'재해/재난', 5:'농어촌', 6:'주거환경', 7:'보건의료',
                     8:'교육', 9:'행정지원', 10:'상담', 11:'문화', 12:'체육', 13:'역사', 14:'동아리', 15:'여행', 16:'홍보',
                    17:'사회공헌', 18:'기획', 19:'언어', 20:'현장', 21:'기타'}
    receiver_dict = {0:'장애인', 1:'노인', 2:'외국인', 3:'노숙인', 4:'다문화가정', 5:'노동자', 6:'유아', 7:'여성', 8:'쪽방촌', 9:'청소년', 10:'지역사회'}
    """
    category_enum = enumerate(['생활편의', '국제협력', '환경', '인권', '재해/재난', '농어촌', '주거환경', '보건의료',
                       '교육', '행정지원', '상담', '문화', '체육', '역사', '동아리', '여행', '홍보',
                       '사회공헌', '기획', '언어', '현장', '기타'])
    
    receiver_cate_enum = enumerate(['장애인','노인','외국인','노숙인','다문화가정','노동자','유아','여성','쪽방촌','청소년','지역사회'])
    """

    #생활 편의	국제 협력	환경	인권	재해/재난	농어촌	주거 환경	보건 의료	교육	행정 지원	상담
    # 문화	체육	역사	동아리	여행	홍보	사회공헌	기획	언어	현장	기타
    # 장애인	노인	외국인	노숙인	다문화가정	노동자	유아	여성	쪽방촌	청소년	지역사회
    for i in range(category_num):
        if categories[i] > 0:
            category_names += category_dict[i] + ', '
        if i == category_num - 1:  # 맨마지막 index일 때
            if category_names[-2:] == ', ':
                category_names = category_names[:-2]

    for i in range(receiver_cate_num):
        if categories[category_num+i] > 0:
            category_receivers += receiver_dict[i] + ', '
        if i == receiver_cate_num-1:  # 맨마지막 index일 때 맨 뒤에 ','빼기
            if category_receivers[-2:] == ', ':
                category_receivers = category_receivers[:-2]

    return category_names, category_receivers  # 문자열로 return


#@app.route('/<contents_id>')
@app.route('/')
def blog_detail():
    # db 연결
    conn = sqlite3.connect('volunteer.db')
    cur = conn.cursor()

    # query
    cur.execute("select * from utf8_merge") # content_id에 해당하는 컨텐츠 가져오기

    # data fetch
    row = cur.fetchone()
    category_names, category_receivers = classification(row[8:-5])
#    for row in rows:
#        print(row)

    # 봉사대상, 봉사분류
    if len(category_receivers) == 0:
        category_receivers = '전체시민'
    if len(category_names) == 0:
        category_names = ''

    # 모집기간
#    if row[6] == '00000000':
#        recruit_date = '상시'
#    else:
#    recruit_date = row[5] + ' ~ ' + row[6]
    print(row[4])
    conn.close()

    return render_template('blog-detail.html', contents=row, category_receiver = category_receivers,
                           category_name = category_names)




""" 좋아요 수 가져오기 -> table에서
    또 좋아요 버튼 만들기 -> db에 연결해야함
    text 되는지 확인
    해당하는 카테고리의 다른 contents로 연결 -> contents 분야별로 보여줄 수 있도록?

"""

"""
@app.route('/test', methods=['POST'])
def hello_world_id():
    login_id = request.form['login']
    login_pwd = request.form['password']

    user = User()
    user.id = login_id
    user.pwd = login_pwd
    db.session.add(user)
    db.session.commit()

    return render_template('test.html',id=login_id,pwd=login_pwd)
"""

if __name__ == '__main__':
    app.run()
